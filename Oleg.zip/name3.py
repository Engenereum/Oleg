import os
import pygame
import pygame.display
from pygame import Surface
from pygame.sprite import Sprite


class Player(Sprite):
    def __init__(self):
        super().__init__()
        self.anims = {
            "down": Animation("2/1/down/"),
            "right": Animation("2/1/right/"),
            "up": Animation("2/1/up/"),
            "left": Animation("2/1/left/"),
        }
        self.image = self.anims["down"].image
        self.rect = self.image.get_rect()
        self.current_anim = "down"
        self.anim = self.anims[self.current_anim]

    def update(self, events, keys):
        for event in events:
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_w:
                    self.current_anim = "up"
                if event.key == pygame.K_s:
                    self.current_anim = "down"
                if event.key == pygame.K_d:
                    self.current_anim = "right"
                if event.key == pygame.K_a:
                    self.current_anim = "left"

        self.anim = self.anims[self.current_anim]
        self.anim.update()
        self.image = self.anim.image
        x, y = self.rect.center
        if keys[pygame.K_s]:
            y += 10
        if keys[pygame.K_w]:
            y -= 10
        if keys[pygame.K_a]:
            x -= 10
        if keys[pygame.K_d]:
            x += 10
        self.rect = self.image.get_rect(center=(x,y))

    def draw(self, screen: Surface):
        screen.blit(self.image, self.rect)

class Animation:
    def __init__(self, path):
        self.path = path
        files = os.listdir(path)
        self.images = []
        for file in files:
            image = pygame.image.load(f"{self.path}{file}").convert()
            image = pygame.transform.scale(image, (200, 200))
            self.images.append(image)
        self.index = 0
        self.image = self.images[self.index]

    def update(self):
        self.index += 1
        self.index %= len(self.images)
        self.image = self.images[self.index]

    def draw(self, screen: Surface):
        screen.blit(self.image, (0, 0))

class App:
    def __init__(self):
        self.screen = pygame.display.set_mode((1920, 1080))
        self.clock = pygame.time.Clock()
        self.player = Player()

    def run(self):
        running = True
        while running:
            events =pygame.event.get()
            for event in events:
                if event.type == pygame.QUIT:
                    running = False
            keys = pygame.key.get_pressed()
            self.player.update(events, keys)
            self.screen.fill((255,255,255))
            self.player.draw(self.screen)
            pygame.display.flip()
            self.clock.tick(30)


if __name__ == "__main__":
    app = App()
    app.run()
